"""
Gestionnaire ASGI unifié pour Django et FastMCP.
"""

import logging
from typing import Any, Callable, Awaitable

logger = logging.getLogger(__name__)


class MCPASGIHandler:
    """
    Gestionnaire ASGI unifié pour Django et FastMCP.
    """
    
    def __init__(self, asgi_handler) -> None:
        # Import différé pour éviter les circulaires
        from ..server import mcp_server, MCP_CONFIG
        from django.conf import settings as django_settings
        
        self.mcp_server = mcp_server
        self.mcp_path = getattr(django_settings, "MCP_HTTP_PATH", MCP_CONFIG["path"])
        self.mcp_app = mcp_server.http_app(
            transport=MCP_CONFIG["transport"],
            path=self.mcp_path,
        )
        self.asgi_handler = asgi_handler

    async def __call__(
        self, 
        scope: dict[str, Any], 
        receive: Callable[[], Awaitable[dict[str, Any]]], 
        send: Callable[[dict[str, Any]], Awaitable[None]]
    ) -> None:
        """
        Point d'entrée ASGI unifié.
        """
        if scope["type"] != "http":
            raise ValueError(
                f"MCP peut uniquement gérer les connexions ASGI/HTTP, pas {scope['type']}."
            )

        
        # Vérifie si c'est une requête MCP
        path: str = scope.get("path", "")
        if path.startswith(self.mcp_path):
            # Route vers FastMCP
            await self.mcp_app(scope, receive, send)
        else:
            # Route vers Django
            await self.asgi_handler(scope, receive, send)
            
