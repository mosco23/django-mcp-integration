import logging
import django
from django.conf import settings
from django.core.handlers.wsgi import WSGIHandler
from .handlers.wsgi import MCPWSGIHandler

logger = logging.getLogger("MCPWSGIHandler")

def get_wsgi_application():
    """
    The public interface to Django's WSGI support. Return a WSGI callable.

    Avoids making django.core.handlers.WSGIHandler a public API, in case the
    internal WSGI implementation changes or moves in the future.
    """
    django.setup(set_prefix=False)
    django_handle = WSGIHandler()
    if getattr(settings, 'MCP_ENABLED', True):
        logger.info("🚀 Django MCP Integration WSGI activée")
        return MCPWSGIHandler(django_handle)
    else:
        logger.info("🔧 Django WSGI standard (MCP désactivé)")
        return WSGIHandler()



application = get_wsgi_application()