
from ..server import mcp_server

# Middleware pour injecter l'objet request Django
@mcp_server.middleware
async def django_request_middleware(request, call_next):
    """
    Middleware qui injecte l'objet request Django dans le contexte.
    Nécessaire pour les permissions qui vérifient request.user, etc.
    """
    from django.http import HttpRequest
    from django.contrib.auth.models import AnonymousUser
    
    # Créer une requête Django simulée si nécessaire
    if not hasattr(request, '_django_request'):
        django_request = HttpRequest()
        django_request.method = request.method
        django_request.path = request.url.path
        django_request.user = AnonymousUser()  # Par défaut
        
        # Vous pouvez peupler davantage la requête Django ici
        # en fonction de votre système d'authentification
        
        request._django_request = django_request
    
    
    # Passer au handler suivant
    return await call_next(request)



# Middleware pour la gestion des permissions
@mcp_server.middleware
async def permission_middleware(request, call_next):
    """
    Middleware qui vérifie les permissions avant d'exécuter les outils.
    """
    from django_mcp_integration.tools.registry import registry
    
    # Vérifier si c'est une requête d'outil
    if hasattr(request, 'tool_name'):
        tool_name = request.tool_name
        
        # Récupérer l'outil
        tool_info = registry.get_tool_info(tool_name)
        if tool_info:
            # Vérifier les permissions
            for permission in tool_info.permission_classes:
                if not permission.has_permission(request._django_request, tool_info.wrapper):
                    from fastmcp.exceptions import FastMCPError
                    raise FastMCPError(
                        code="PERMISSION_DENIED",
                        message=f"Permission refusée pour l'outil {tool_name}"
                    )
    
    return await call_next(request)

