import logging
from fastmcp import FastMCP
from django.conf import settings


logger = logging.getLogger(__name__)


class MCPConfig:
    """Configuration pour MCP."""
    
    @property
    def config(self):
        """Retourne la configuration MCP."""
        server_name = "Django MCP Integration Server"
        return {
            "name": getattr(settings, "MCP_SERVER_NAME", server_name),
            "version": "0.0.4",
            "instructions": getattr(settings, "MCP_SERVER_INSTRUCTIONS", None),
            "host": getattr(settings, "MCP_HOST", 'localhost'),
            "port": getattr(settings, "MCP_PORT", 8000),
            "transport": getattr(settings, "MCP_TRANSPORT", "http"),
            "enabled": getattr(settings, "MCP_ENABLED", True),
            "path": getattr(settings, "MCP_HTTP_PATH", '/mcp/'),
        }


# Initialisation sécurisée
mcp_config = MCPConfig()
MCP_CONFIG = mcp_config.config


# Création du serveur MCP avec middleware de sécurité
mcp_server = FastMCP(
    name=MCP_CONFIG["name"],
    instructions=MCP_CONFIG["instructions"],
    version=MCP_CONFIG["version"],
)


