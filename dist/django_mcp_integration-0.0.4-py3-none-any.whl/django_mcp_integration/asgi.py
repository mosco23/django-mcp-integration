import logging
import django
from django.conf import settings
from django.core.handlers.asgi import ASGIHandler
from .handlers.asgi import MCPASGIHandler


logger = logging.getLogger("MCPASGIHandler")

def get_asgi_application():
    """
    Retourne l'application ASGI unifiée Django-MCP.
    
    Usage typique dans asgi.py:
        from django_mcp_integration.asgi import get_asgi_application
        application = get_asgi_application()
    """
    
    django.setup(set_prefix=False)
    django_handle = ASGIHandler()
    # Vérifie si l'intégration MCP est activée
    if getattr(settings, 'MCP_ENABLED', True):
        logger.info("🚀 Django MCP Integration ASGI activée")
        return MCPASGIHandler(django_handle)
    else:
        logger.info("🔧 Django ASGI standard (MCP désactivé)")
        return ASGIHandler()


# Application ASGI par défaut
application = get_asgi_application()