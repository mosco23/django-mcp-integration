from typing import Any, Callable, Optional, Dict, Type, get_type_hints, List, Union, TypeVar, Literal
from mcp.types import Icon, ToolAnnotations
from fastmcp.utilities.types import NotSetT, NotSet
from fastmcp import FastMCP
from .tool import ToolResultSerializerType
from ..permissions import BaseHasAPIKey, AllowAny
import inspect
import logging
from dataclasses import dataclass
from abc import ABC, abstractmethod
from django.http import HttpRequest



logger = logging.getLogger(__name__)

T = TypeVar('T')


@dataclass
class ToolConfig:
    """Configuration d'un outil MCP."""
    name: Optional[str] = None
    title: str | None = None
    description: Optional[str] = None
    permission_classes: Optional[List[Union[BaseHasAPIKey, Type[BaseHasAPIKey]]]] = None
    input_schema: Optional[Dict[str, Any]] = None
    rate_limit: Optional[int] = None
    icons: list[Icon] | None = None
    tags: set[str] | None = None
    annotations: ToolAnnotations | None = None
    exclude_args: list[str] | None = None
    output_schema: dict[str, Any] | NotSetT | Literal[False] | None = NotSet
    serializer: ToolResultSerializerType | None = None
    meta: dict[str, Any] | None = None
    enabled: bool | None = None


class ToolWrapper(ABC):
    """Wrapper abstrait pour tous les outils."""
    
    def __init__(self, server: FastMCP, config: ToolConfig):
        self.config = config
        self._validate()
        self.server = server
        self._tool = self.server.tool(
            self.execute,
            name=self.config.name,
            title=self.config.title,
            description=self.config.description,
            icons=self.config.icons,
            tags=self.config.tags,
            annotations=self.config.annotations,
            exclude_args=self.config.exclude_args,
            output_schema=self.config.output_schema,
            serializer=self.config.serializer,
            meta=self.config.meta,
            enabled=self.config.enabled
        )
        
    
    def _validate(self):
        """Valide la configuration de l'outil."""
        if not self.config.name:
            raise ValueError("Le nom de l'outil est requis")
        
        # Valider les permissions
        for perm in self.config.permission_classes:
            if not isinstance(perm, BaseHasAPIKey):
                raise TypeError(f"Permission invalide: {perm}")
    
    async def check_permissions(self, request: HttpRequest) -> bool:
        """Vérifie si la requête a les permissions nécessaires."""
        for permission in self.config.permission_classes:
            if not permission.has_permission(request, self):
                logger.warning(f"Permission refusée: {permission.__class__.__name__}")
                return False
        return True
    
    @abstractmethod
    async def execute(self, params: Dict) -> Any:
        """Exécute l'outil."""
        pass
    
    def get_schema(self) -> Dict[str, Any]:
        """Retourne le schéma de l'outil."""
        return self.config.input_schema or {}


class FunctionToolWrapper(ToolWrapper):
    """Wrapper pour les fonctions."""
    
    def __init__(self, server: FastMCP, config: ToolConfig, func: Callable):
        super().__init__(server, config)
        self.func = func
        self._build_schema()
    
    def _build_schema(self):
        """Construit le schéma depuis la fonction."""
        if self.config.input_schema is None:
            self.config.input_schema = self._infer_schema()
    
    def _infer_schema(self) -> Dict[str, Any]:
        """Infère le schéma depuis les annotations de type."""
        sig = inspect.signature(self.func)
        type_hints = get_type_hints(self.func)
        
        properties = {}
        required = []
        
        for param_name, param in sig.parameters.items():
            if param_name == 'request':
                continue
                
            if param.kind in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
                continue
            
            param_type = type_hints.get(param_name, str)
            param_schema = self._type_to_schema(param_type)
            
            if param.default == param.empty:
                required.append(param_name)
            
            properties[param_name] = param_schema
        
        return {
            "type": "object",
            "properties": properties,
            "required": required,
            "additionalProperties": False
        }
    
    def _type_to_schema(self, param_type) -> Dict[str, Any]:
        """Convertit un type Python en schéma JSON."""
        type_map = {
            str: {"type": "string"},
            int: {"type": "integer"},
            float: {"type": "number"},
            bool: {"type": "boolean"},
            list: {"type": "array", "items": {"type": "string"}},
            dict: {"type": "object"},
        }
        
        origin = getattr(param_type, '__origin__', None)
        if origin is list:
            # Gestion de List[Type]
            args = getattr(param_type, '__args__', [str])
            return {"type": "array", "items": self._type_to_schema(args[0])}
        
        return type_map.get(param_type, {"type": "string"})
    
    async def execute(self, params: Dict) -> Any:
        """Exécute la fonction avec les paramètres."""
        from fastmcp.server.dependencies import get_context
        
        if self.check_permissions(HttpRequest()):
            # Filtre les paramètres valides
            ctx = get_context()
            sig = inspect.signature(self.func)
            valid_params = {}
            
            for param_name in sig.parameters:
                if param_name in params:
                    valid_params[param_name] = params[param_name]
            
            return await self.func(ctx, **valid_params)
        else:
            return await {
                "status": 403,
                "message": "PERMISSSION DENIED",
            }


class ClassToolWrapper(ToolWrapper):
    """Wrapper pour les classes."""
    
    def __init__(self, server: FastMCP, config: ToolConfig, cls: Type):
        super().__init__(server, config)
        self.cls = cls
        
        # Vérifie que la classe a une méthode execute
        if not hasattr(cls, 'execute'):
            raise ValueError(f"La classe {cls.__name__} doit avoir une méthode 'execute'")
        
        if not inspect.iscoroutinefunction(cls.execute):
            raise ValueError(f"La méthode 'execute' doit être asynchrone")
        
        self._build_schema()
    
    def _build_schema(self):
        """Construit le schéma depuis la classe."""
        if self.config.input_schema is None:
            self.config.input_schema = self._infer_schema()
    
    def _infer_schema(self) -> Dict[str, Any]:
        """Infère le schéma depuis la méthode execute."""
        execute_method = getattr(self.cls, 'execute')
        sig = inspect.signature(execute_method)
        type_hints = get_type_hints(execute_method)
        
        properties = {}
        required = []
        
        for param_name, param in sig.parameters.items():
            if param_name == 'self':
                continue
                
            if param_name == 'request':
                continue
                
            if param.kind in (param.VAR_POSITIONAL, param.VAR_KEYWORD):
                continue
            
            param_type = type_hints.get(param_name, str)
            param_schema = self._type_to_schema(param_type)
            
            if param.default == param.empty:
                required.append(param_name)
            
            properties[param_name] = param_schema
        
        return {
            "type": "object",
            "properties": properties,
            "required": required,
            "additionalProperties": False
        }
    
    def _type_to_schema(self, param_type) -> Dict[str, Any]:
        """Convertit un type Python en schéma JSON."""
        type_map = {
            str: {"type": "string"},
            int: {"type": "integer"},
            float: {"type": "number"},
            bool: {"type": "boolean"},
            list: {"type": "array", "items": {"type": "string"}},
            dict: {"type": "object"},
        }
        
        origin = getattr(param_type, '__origin__', None)
        if origin is list:
            args = getattr(param_type, '__args__', [str])
            return {"type": "array", "items": self._type_to_schema(args[0])}
        
        return type_map.get(param_type, {"type": "string"})
    
    async def execute(self, params: Dict) -> Any:
        """Crée une instance et exécute la méthode execute."""
        from fastmcp.server.dependencies import get_context
        
        if self.check_permissions(HttpRequest()):
            ctx = get_context()
            instance = self.cls()
            # Filtre les paramètres valides
            execute_method = getattr(self.cls, 'execute')
            sig = inspect.signature(execute_method)
            valid_params = {}
            
            for param_name in sig.parameters:
                if param_name == 'self':
                    continue
                
                elif param_name in params:
                    valid_params[param_name] = params[param_name]
            
            return await instance.execute(ctx, **valid_params)
        else:
            return await {
                "status": 403,
                "message": "PERMISSSION DENIED",
            }


def mcp_tool(
    tool_config: ToolConfig | None = None
):
    """
    Décorateur unifié pour créer des outils MCP.
    
    Args:
        name: Nom de l'outil
        description: Description de l'outil
        permission_classes: Liste de classes de permission (noms strings, instances ou classes)
        input_schema: Schéma JSON Schema personnalisé
        rate_limit: Limite de requêtes par minute
        require_request: Si True, passe l'objet request comme paramètre
    
    Returns:
        Décorateur pour fonction ou classe
    """
    config = tool_config or ToolConfig()
    def decorator(target):
        # Déterminer le nom et la description
        
        config.name = config.name or getattr(target, '__name__', target.__class__.__name__)
        tool_doc = getattr(target, '__doc__', '')
        config.description = config.description or (tool_doc and tool_doc.strip().split('\n')[0]) or f"Outil {config.name}"
        
        # Résoudre les permissions
        permissions = []
        if config.permission_classes:
            for perm in config.permission_classes:
                if isinstance(perm, BaseHasAPIKey):
                    permissions.append(perm)
                elif isinstance(perm, type) and issubclass(perm, BaseHasAPIKey):
                    permissions.append(perm())
                else:
                    raise ValueError(f"Type de permission non supporté: {type(perm)}")
        else:
            permissions.append(AllowAny())
            
        from ..server import mcp_server
        
        # Créer le wrapper approprié
        if inspect.isclass(target):
            wrapper = ClassToolWrapper(server=mcp_server, config=config, cls=target)
        else:
            wrapper = FunctionToolWrapper(server=mcp_server, config=config, func=target)
        
        # Enregistrer dans le registry
        from .registry import registry
        registry.register(wrapper)
        logger.info(f"🛠️ Outil MCP enregistré: {config.name} (permissions: {[p.__class__.__name__ for p in permissions]})")
        return target
    
    return decorator

