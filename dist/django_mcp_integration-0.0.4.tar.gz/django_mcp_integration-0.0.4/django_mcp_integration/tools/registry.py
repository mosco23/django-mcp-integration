# base.py
from typing import Any, Dict, List, Optional
import logging
from dataclasses import dataclass
from django.http import HttpRequest
from ..permissions import BaseHasAPIKey

logger = logging.getLogger(__name__)


@dataclass
class ToolInfo:
    """Informations sur un outil enregistré."""
    name: str
    description: str
    wrapper: Any
    permission_classes: List[BaseHasAPIKey]
    input_schema: Dict[str, Any]


class ToolRegistry:
    """Registry global pour les outils MCP."""
    
    _instance = None
    _tools: Dict[str, ToolInfo] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
        return cls._instance
    
    def register(self, wrapper: Any):
        """Enregistre un wrapper d'outil."""
        tool_name = getattr(wrapper, 'config').name
        
        # Récupérer les informations
        config = getattr(wrapper, 'config')
        
        tool_info = ToolInfo(
            name=tool_name,
            description=config.description,
            wrapper=wrapper,
            permission_classes=config.permission_classes,
            input_schema=config.input_schema,
        )
        
        self._tools[tool_name] = tool_info
        logger.info(f"📝 Outil enregistré: {tool_name}")
    
    async def execute(self, request: HttpRequest, tool_name: str, params: Dict) -> Any:
        """
        Exécute un outil avec vérification des permissions.
        
        Args:
            tool_name: Nom de l'outil
            params: Paramètres d'entrée
            request: Objet requête pour les permissions
        
        Returns:
            Résultat de l'exécution
        
        Raises:
            ValueError: Si l'outil n'existe pas
            PermissionError: Si les permissions sont insuffisantes
        """
        if tool_name not in self._tools:
            raise ValueError(f"Outil non trouvé: {tool_name}")
        
        tool_info = self._tools[tool_name]
        wrapper = tool_info.wrapper
        
        # Vérifier les permissions
        if not await wrapper.check_permissions(request):
            raise PermissionError(f"Permissions insuffisantes pour l'outil: {tool_name}")
        
        # Valider les paramètres
        if tool_info.input_schema:
            self._validate_params(params, tool_info.input_schema)
        
        # Exécuter l'outil
        try:
            result = await wrapper.execute(request, params)
            logger.debug(f"✅ Outil exécuté: {tool_name}")
            return result
        except Exception as e:
            logger.error(f"❌ Erreur d'exécution de l'outil {tool_name}: {e}")
            raise
    
    def _validate_params(self, params: Dict, schema: Dict):
        """Valide les paramètres contre le schéma (simplifié)."""
        # Implémentation basique - à améliorer avec une vraie validation JSON Schema
        required = schema.get('required', [])
        properties = schema.get('properties', {})
        
        for field in required:
            if field not in params:
                raise ValueError(f"Paramètre requis manquant: {field}")
        
        for field, value in params.items():
            if field in properties:
                field_schema = properties[field]
                expected_type = field_schema.get('type')
                
                if expected_type == 'string' and not isinstance(value, str):
                    raise ValueError(f"Le paramètre '{field}' doit être une chaîne")
                elif expected_type == 'integer' and not isinstance(value, int):
                    raise ValueError(f"Le paramètre '{field}' doit être un entier")
    
    def get_tool_info(self, tool_name: str) -> Optional[ToolInfo]:
        """Récupère les informations d'un outil."""
        return self._tools.get(tool_name)
    
    
    def list_tools(self) -> List[Dict[str, Any]]:
        """
        Liste les outils disponibles avec leurs permissions.
        
        Args:
            request: Objet requête pour filtrer par permissions
        
        Returns:
            Liste d'outils avec leurs métadonnées
        """
        tools_list = []
        
        for tool_name, tool_info in self._tools.items():
            tool_data = {
                'name': tool_name,
                'description': tool_info.description,
                'permissions': [p.__class__.__name__ for p in tool_info.permission_classes],
                'input_schema': tool_info.input_schema,
            }
            tools_list.append(tool_data)
        
        return tools_list
    
    def clear(self):
        """Vide le registry."""
        self._tools.clear()
        logger.debug("🧹 Registry vidé")


# Instance globale
registry = ToolRegistry()