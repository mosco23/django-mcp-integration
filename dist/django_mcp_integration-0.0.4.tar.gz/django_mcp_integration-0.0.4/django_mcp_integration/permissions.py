# permissions.py
"""
Système de permissions inspiré de Django REST Framework.
Les développeurs peuvent créer leurs propres classes de permission.
"""

from abc import ABC, abstractmethod
from typing import Optional, Type
import logging
from django.http import HttpRequest
from django.conf import settings
from .models import AbstractAPIKey, APIKey

logger = logging.getLogger(__name__)


class KeyParser:
    keyword = "Api-Key"

    def get(self, request: HttpRequest) -> Optional[str]:
        custom_header = getattr(settings, "API_KEY_CUSTOM_HEADER", None)

        if custom_header is not None:
            return self.get_from_header(request, custom_header)

        return self.get_from_authorization(request)

    def get_from_authorization(self, request: HttpRequest) -> Optional[str]:
        authorization = request.META.get("HTTP_AUTHORIZATION", "")

        if not authorization:
            return None

        keyword, found, key = authorization.partition(" ")

        if not found:
            return None

        if keyword.lower() != self.keyword.lower():
            return None

        return key

    def get_from_header(self, request: HttpRequest, name: str) -> Optional[str]:
        return request.META.get(name) or None
    
    

class BaseHasAPIKey(ABC):
    """
    Classe de base pour toutes les permissions.
    Les développeurs doivent hériter de cette classe.
    
    Exemple d'usage:
        class IsPostOwner(BaseHasAPIKey):
            def has_permission(self, request, tool):
                return request.user.is_authenticated
            
            def has_object_permission(self, request, tool, obj):
                return obj.owner == request.user
    """
    
    model: Optional[Type[AbstractAPIKey]] = None
    key_parser = KeyParser()
    
    def get_key(self, request: HttpRequest) -> Optional[str]:
        return self.key_parser.get(request)
    
    
    @abstractmethod
    def has_permission(self, request, tool) -> bool:
        """
        Retourne True si la requête doit être autorisée.
        
        Args:
            request: L'objet requête (peut être None dans certains cas)
            tool: L'outil MCP qui sera exécuté
        
        Returns:
            bool: True si autorisé, False sinon
        """
        assert self.model is not None, (
            "%s must define `.model` with the API key model to use"
            % self.__class__.__name__
        )
        key = self.get_key(request)
        if not key:
            return False
        return self.model.objects.is_valid(key)
    
    
    def has_object_permission(self, request, tool, obj) -> bool:
        """
        Retourne True si la requête doit être autorisée pour l'objet spécifique.
        
        Args:
            request: L'objet requête
            tool: L'outil MCP
            obj: L'objet sur lequel l'action est effectuée
        
        Returns:
            bool: True si autorisé, False sinon
        """
        return True



class HasAPIKey(BaseHasAPIKey):
    model = APIKey


# ==================== PERMISSIONS INTÉGRÉES ====================

class AllowAny(BaseHasAPIKey):
    """Autorise tout le monde (par défaut)."""
    
    def has_permission(self, request: HttpRequest, tool) -> bool:
        return True

    

class IsAuthenticated(HasAPIKey):
    """Nécessite que l'utilisateur soit authentifié."""
    
    def has_permission(self, request: HttpRequest, tool) -> bool:
        return request.user.is_authenticated


class IsAdminUser(HasAPIKey):
    """Nécessite que l'utilisateur soit administrateur."""
    
    def has_permission(self, request: HttpRequest, tool) -> bool:
        return bool(
            request.user.is_authenticated and 
            request.user.is_staff
        )


class IsSuperUser(HasAPIKey):
    """Nécessite que l'utilisateur soit superutilisateur."""
    
    def has_permission(self, request: HttpRequest, tool) -> bool:
        return bool(
            request.user.is_authenticated and 
            request.user.is_superuser
        )


class IsReadOnly(HasAPIKey):
    """Autorise uniquement les méthodes de lecture (GET, HEAD, OPTIONS)."""
    
    def has_permission(self, request: HttpRequest, tool) -> bool:
        if not request:
            return True
        return getattr(request, 'method', 'GET') in ['GET', 'HEAD', 'OPTIONS']


# ==================== PERMISSIONS COMPOSÉES ====================

class AndPermission(HasAPIKey):
    """Combinaison logique ET entre plusieurs permissions."""
    
    def __init__(self, *permissions: BaseHasAPIKey):
        self.permissions = permissions
    
    def has_permission(self, request: HttpRequest, tool) -> bool:
        return all(perm.has_permission(request, tool) for perm in self.permissions)


class OrPermission(HasAPIKey):
    """Combinaison logique OU entre plusieurs permissions."""
    
    def __init__(self, *permissions: BaseHasAPIKey):
        self.permissions = permissions
    
    def has_permission(self, request: HttpRequest, tool) -> bool:
        return any(perm.has_permission(request, tool) for perm in self.permissions)


class NotPermission(HasAPIKey):
    """Inverse une permission."""
    
    def __init__(self, permission: BaseHasAPIKey):
        self.permission = permission
    
    def has_permission(self, request: HttpRequest, tool) -> bool:
        return not self.permission.has_permission(request, tool)




